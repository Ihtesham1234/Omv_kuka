import numpy as np

class KukaPickPlaceScenario:
    """Simple KUKA pick-and-place sequence without IK (teleports cubes)."""

    def __init__(self):
        self._robot = None
        self._cubes = []
        self._conveyor = None
        self._running = False
        self._current_idx = 0
        self._state = "idle"
        self._time_acc = 0.0
        self._control_dt = 1.0 / 15.0  # update rate

    def setup_scenario(self, robot, cubes, conveyor):
        self._robot = robot
        self._cubes = cubes
        self._conveyor = conveyor
        self._running = len(cubes) > 0
        self._current_idx = 0
        self._state = "move_to_pick" if self._running else "idle"
        self._time_acc = 0.0

        # Record cube start positions
        self._pick_positions = [c.get_world_pose()[0] for c in cubes]
        base_pos = np.array(self._conveyor.get_world_pose()[0])
        self._place_positions = [base_pos + np.array([0.4 + 0.1 * i, 0, 0.1]) for i in range(len(cubes))]

        print(f"[Scenario] Initialized with {len(cubes)} cubes. Starting pick-and-place...")

    def teardown_scenario(self):
        self._running = False
        self._state = "idle"
        self._current_idx = 0
        print("[Scenario] Stopped.")

    def update_scenario(self, step: float):
        if not self._running:
            return

        self._time_acc += step
        if self._time_acc < self._control_dt:
            return
        self._time_acc = 0.0

        if self._current_idx >= len(self._cubes):
            print("[Scenario] All cubes placed. Done ✅")
            self._running = False
            self._state = "idle"
            return

        cube = self._cubes[self._current_idx]
        pick = np.array(self._pick_positions[self._current_idx])
        place = np.array(self._place_positions[self._current_idx])

        if self._state == "move_to_pick":
            print(f"[Scenario] Moving to pick cube {self._current_idx+1}")
            self._state = "pick"

        elif self._state == "pick":
            print(f"[Scenario] Picking cube {self._current_idx+1}")
            cube.set_world_pose(pick + np.array([0, 0, 0.05]))
            self._state = "move_to_place"

        elif self._state == "move_to_place":
            print(f"[Scenario] Moving to place cube {self._current_idx+1}")
            self._state = "place"

        elif self._state == "place":
            print(f"[Scenario] Placing cube {self._current_idx+1}")
            cube.set_world_pose(place)
            self._current_idx += 1
            if self._current_idx >= len(self._cubes):
                print("[Scenario] Task complete ✅")
                self._running = False
                self._state = "idle"
            else:
                self._state = "move_to_pick"
