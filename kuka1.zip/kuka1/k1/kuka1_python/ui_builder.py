import numpy as np
import omni.timeline
import omni.ui as ui
from isaacsim.core.api.world import World
from isaacsim.core.prims import SingleArticulation, XFormPrim
from isaacsim.core.utils.stage import add_reference_to_stage, create_new_stage, get_current_stage
from isaacsim.examples.extension.core_connectors import LoadButton, ResetButton
from isaacsim.gui.components.element_wrappers import CollapsableFrame, StateButton
from isaacsim.gui.components.ui_utils import get_style
from omni.usd import StageEventType
from pxr import Sdf, UsdLux

from .scenario import KukaPickPlaceScenario


class UIBuilder:
    def __init__(self):
        self.frames = []
        self.wrapped_ui_elements = []
        self._timeline = omni.timeline.get_timeline_interface()
        self._on_init()

    ###############################################################################
    # Callbacks used by extension.py
    ###############################################################################
    def on_menu_callback(self):
        pass

    def on_timeline_event(self, event):
        if event.type == int(omni.timeline.TimelineEventType.STOP):
            self._scenario_state_btn.reset()
            self._scenario_state_btn.enabled = False

    def on_physics_step(self, step: float):
        pass

    def on_stage_event(self, event):
        if event.type == int(StageEventType.OPENED):
            self._reset_extension()

    def cleanup(self):
        for ui_elem in self.wrapped_ui_elements:
            ui_elem.cleanup()

    ###############################################################################
    # Build UI
    ###############################################################################
    def build_ui(self):
        world_controls_frame = CollapsableFrame("World Controls", collapsed=False)

        with world_controls_frame:
            with ui.VStack(style=get_style(), spacing=5, height=0):
                self._load_btn = LoadButton(
                    "Load Scene",
                    "LOAD",
                    setup_scene_fn=self._setup_scene,
                    setup_post_load_fn=self._setup_scenario,
                )
                self._load_btn.set_world_settings(physics_dt=1 / 120.0, rendering_dt=1 / 60.0)
                self.wrapped_ui_elements.append(self._load_btn)

                self._reset_btn = ResetButton(
                    "Reset Scene", "RESET", pre_reset_fn=None, post_reset_fn=self._on_post_reset_btn
                )
                self._reset_btn.enabled = False
                self.wrapped_ui_elements.append(self._reset_btn)

        run_frame = CollapsableFrame("Run Scenario")
        with run_frame:
            with ui.VStack(style=get_style(), spacing=5, height=0):
                self._scenario_state_btn = StateButton(
                    "Run Scenario",
                    "RUN",
                    "STOP",
                    on_a_click_fn=self._on_run_scenario_a_text,
                    on_b_click_fn=self._on_run_scenario_b_text,
                    physics_callback_fn=self._update_scenario,
                )
                self._scenario_state_btn.enabled = False
                self.wrapped_ui_elements.append(self._scenario_state_btn)

    ###############################################################################
    # Scene and Scenario Setup
    ###############################################################################
    def _on_init(self):
        self._articulation = None
        self._cubes = []
        self._conveyor = None
        self._scenario = KukaPickPlaceScenario()

        # TODO: Change this path to your real scene USD path
        self.SCENE_USD_PATH = "/home/omv/Downloads/Default.usd"

    def _add_light(self):
        light = UsdLux.SphereLight.Define(get_current_stage(), Sdf.Path("/World/Light"))
        light.CreateIntensityAttr(100000)
        light.CreateRadiusAttr(2)

    def _setup_scene(self):
        """Loads your full scene (robot + cubes + conveyor)."""
        create_new_stage()
        self._add_light()
        add_reference_to_stage(self.SCENE_USD_PATH, "/World")

        world = World.instance()

        # TODO: Update these prim paths to match your actual USD
        robot_prim_path = "/World/KUKA"
        cube_paths = [
            "/World/Cubes/Pickup_A",
            "/World/Cubes/Pickup_B",
            "/World/Cubes/Pickup_C",
            "/World/Cubes/Pickup_D",
        ]
        conveyor_path = "/World/Xform/ConveyorBelt_A06/Belt/SM_ConveyorBelt_A06_Belt_02"

        try:
            self._articulation = SingleArticulation(robot_prim_path)
        except Exception as e:
            print(f"[UIBuilder] Failed to create articulation: {e}")
            self._articulation = None

        self._cubes = []
        for path in cube_paths:
            try:
                self._cubes.append(XFormPrim(path))
            except Exception as e:
                print(f"[UIBuilder] Failed to load cube {path}: {e}")

        try:
            self._conveyor = XFormPrim(conveyor_path)
        except Exception as e:
            print(f"[UIBuilder] Failed to load conveyor: {e}")
            self._conveyor = None

        if self._articulation:
            world.scene.add(self._articulation)
        for cube in self._cubes:
            world.scene.add(cube)
        if self._conveyor:
            world.scene.add(self._conveyor)

    def _setup_scenario(self):
        print("[UIBuilder] Setting up scenario...")
        self._reset_scenario()

        # Enable buttons once loaded successfully
        self._scenario_state_btn.reset()
        self._scenario_state_btn.enabled = True
        self._reset_btn.enabled = True
        print("[UIBuilder] Scenario ready. RUN button enabled ✅")

    def _reset_scenario(self):
        try:
            self._scenario.teardown_scenario()
            self._scenario.setup_scenario(self._articulation, self._cubes, self._conveyor)
        except Exception as e:
            print(f"[UIBuilder] Scenario reset failed: {e}")

    def _on_post_reset_btn(self):
        self._reset_scenario()
        self._scenario_state_btn.reset()
        self._scenario_state_btn.enabled = True

    ###############################################################################
    # Run Logic
    ###############################################################################
    def _update_scenario(self, step: float):
        self._scenario.update_scenario(step)

    def _on_run_scenario_a_text(self):
        print("[UIBuilder] RUN pressed.")
        self._timeline.play()

    def _on_run_scenario_b_text(self):
        print("[UIBuilder] STOP pressed.")
        self._timeline.pause()

    ###############################################################################
    def _reset_extension(self):
        self._on_init()
        self._reset_ui()

    def _reset_ui(self):
        self._scenario_state_btn.reset()
        self._scenario_state_btn.enabled = False
        self._reset_btn.enabled = False
