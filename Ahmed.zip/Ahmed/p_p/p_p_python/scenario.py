from isaacsim.core.api.world import World
from isaacsim.core.prims import SingleArticulation, XFormPrim
from isaacsim.core.utils.xforms import get_world_pose
from isaacsim.core.utils.types import ArticulationAction
from pxr import Gf


class ExampleScenario:
    def __init__(self):
        self.world = World()

        # 🔧 Replace with your actual prim paths
        self._robot_path = "/World/kuka_kr210"
        self._cube_paths = [
            "/World/Cubes/Pickup_A",
            "/World/Cubes/Pickup_B",
            "/World/Cubes/Pickup_C",
            "/World/Cubes/Pickup_D",
        ]

        # 🎯 Replace with actual target positions (for example: second table)
        self._target_positions = [
            Gf.Vec3f(2.2, 0.53761, 0.90758),
            Gf.Vec3f(2.2, 0.07567, 0.90758),
            Gf.Vec3f(2.65876, 0.53761, 0.90758),
            Gf.Vec3f(2.65876, 0.07567, 0.90758),
        ]

        # Initialize robot and cubes
        self._robot = SingleArticulation(self._robot_path)
        self._cubes = [XFormPrim(path) for path in self._cube_paths]

    def setup_scenario(self):
        print("Scenario setup complete.")

    def teardown_scenario(self):
        print("Scenario teardown complete.")
   
    def update_scenario(self):
        print("Starting pick-and-place operation...")
        i=0

        for cube, target_pos in zip(self._cubes, self._target_positions):
            cube_pos = get_world_pose(self._cube_paths[i],False)
            i=i+1
            print(f"Moving to pick cube at {cube_pos}")
            self._move_arm_to(cube_pos)

            print(f"Picking cube: {cube.prim_path}")
            self._pick_cube(cube)

            print(f"Moving to place cube at {target_pos}")
            self._move_arm_to(target_pos)

            print(f"Placing cube at {target_pos}")
            self._place_cube(cube, target_pos)

    def _move_arm_to(self, position):
        """Simulate arm movement by applying joint positions (simplified)."""
        action = ArticulationAction(joint_positions=[0.5] * self._robot.num_joints)
        self._robot.apply_action(action)
        self.world.step(render=True)

    def _pick_cube(self, cube):
        """Optional: simulate grasp or attach logic."""
        pass

    def _place_cube(self, cube, position):
        cube.set_world_pose(position)
        self.world.step(render=True)
