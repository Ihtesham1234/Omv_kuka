import omni.ui as ui
from isaacsim.core.api.world import World
from isaacsim.gui.components.element_wrappers import ScrollingWindow
from isaacsim.gui.components.ui_utils import get_style
from .scenario import ExampleScenario

class UIBuilder:
    def __init__(self):
        self._scenario = ExampleScenario()
        self._scenario.setup_scenario()
        self._build_ui()

    def _build_ui(self):
        # Create a scrollable window for the extension UI
        self._window = ScrollingWindow(
            title="KUKA Pick-and-Place",
            width=400,
            height=300,
            visible=True,
            dockPreference=ui.DockPreference.LEFT_BOTTOM
        )

        with self._window.frame:
            with ui.VStack(style=get_style()):
                ui.Label("Pick-and-Place Controller", style={"margin_height": 10})
                
                # Button to trigger the pick-and-place operation
                ui.Button("Run Pick-and-Place", clicked_fn=self._scenario.update_scenario)

                # Optional: Add more controls or status indicators here

    def cleanup(self):
        self._scenario.teardown_scenario()