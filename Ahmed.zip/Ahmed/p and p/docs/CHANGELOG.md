# Changelog

## [1.0.1] - 2025-01-21
### Changed
- Update extension description and add extension specific test settings


## [0.1.0] - 2025-10-15

### Added

- Initial version of p and p  Extension
